//
//  ViewController.swift
//  CaraLibro
//
//  Created by user190977 on 6/19/22.
//

import UIKit

class ViewController: UIViewController {

    @IBAction private func tapToCloseKeyboard(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
    }
    
}



