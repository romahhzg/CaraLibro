//
//  Constants.swift
//  CaraLibro
//
//  Created by user190977 on 7/17/22.
//

import Foundation

struct Constants{
    
    struct Storyboard {
        
        static let homeViewController = "HomeVC"
        
    }
}
